{
    'name': 'Restrict User Menu (Odoo 17)',
    'version': '17.0.1.0.0',
    'summary': 'Restrict menu access for specific users in Odoo 17',
    'description': '''
        This module allows administrators to hide specific menus from the user interface for designated users in Odoo 17.

        Key features:
            - Granular control over menu visibility
            - Improved user experience by streamlining the interface
            - Enhanced security by restricting access to sensitive areas

        **Note:** This module is compatible with Odoo v17 only.
    ''',
    'category': 'Extra Tools',
    'author': 'Your Name/Company (consider adding your details)',
    'company': 'Your Name/Company (consider adding your details)',
    'maintainer': 'Your Name/Company (consider adding your details)',
    'website': "https://www.yourcompany.com/ (replace with your website)",  # Optional website
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',  # Update for v17 security configuration
        'views/res_users_form.xml',  # Update for v17 view inheritance
    ],
    'license': 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}

